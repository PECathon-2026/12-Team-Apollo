import React, { useState, useEffect } from 'react';
import {
  Satellite,
  Scroll,
  Moon,
  Eye,
  Sword,
  ArrowRight,
  Clock,
  Sparkles,
} from 'lucide-react';
import { NavSectionId } from '../../types';
import { TsukuyomiMoon } from '../../components/TsukuyomiMoon';
import { OrientalClouds } from '../../components/OrientalClouds';
import { LoadingScreen } from '../../components/LoadingScreen';

interface DashboardProps {
  onSelectOption: (option: Exclude<NavSectionId, 'dashboard'>) => void;
}

interface SimpleOptionCard {
  id: Exclude<NavSectionId, 'dashboard'>;
  japanese: string;
  title: string;
  subtitle: string;
  description: string;
  icon: React.ReactNode;
  accentColor: string;
  glowColor: string;
  launchText: string;
}

export const Dashboard: React.FC<DashboardProps> = ({ onSelectOption }) => {
  const [currentTime, setCurrentTime] = useState<string>('');
  const [showFactModal, setShowFactModal] = useState<boolean>(false);

  // Simple live clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const options: SimpleOptionCard[] = [
    {
      id: 'watchtower',
      japanese: '望楼',
      title: 'Space Station Tracker',
      subtitle: 'Live ISS map & dark sky spots',
      description:
        'Track the International Space Station live on the map, see upcoming passes over your location, and find nearby places for stargazing.',
      icon: <Satellite size={26} color="var(--vermilion-bright)" />,
      accentColor: 'var(--vermilion)',
      glowColor: 'var(--vermilion-glow)',
      launchText: 'Open Tracker →',
    },
    {
      id: 'scroll',
      japanese: '天巻',
      title: 'Moon Calendar & Phases',
      subtitle: 'Tonight’s moon & viewing conditions',
      description:
        'Check tonight’s live moon phase, percentage of illumination, rise and set times, and ancient Japanese samurai stargazing chronicles.',
      icon: <Moon size={26} color="var(--gold-moon-bright)" />,
      accentColor: 'var(--gold-moon)',
      glowColor: 'var(--gold-glow)',
      launchText: 'View Moon Phase →',
    },
    {
      id: 'spirit-lens',
      japanese: '霊鏡',
      title: 'Star & Constellation Finder',
      subtitle: 'Photo detection & clan star lore',
      description:
        'Upload night sky photos to automatically identify bright stars, nebulae, and constellations along with their historical samurai clan legends.',
      icon: <Eye size={26} color="#5ad896" />,
      accentColor: '#4e9b72',
      glowColor: 'rgba(78, 155, 114, 0.35)',
      launchText: 'Find Stars & Nebulae →',
    },
    {
      id: 'dojo',
      japanese: '道場',
      title: 'Night Photo Enhancer',
      subtitle: 'Noise reduction & sharpening',
      description:
        'Clean up grainy astrophotography, sharpen dim stellar profiles, and compare your before and after results with an interactive slider.',
      icon: <Sword size={26} color="var(--katana-steel)" />,
      accentColor: 'var(--katana-steel)',
      glowColor: 'rgba(154, 169, 191, 0.35)',
      launchText: 'Enhance Photos →',
    },
  ];

  return (
    <div className="dashboard-with-bg-theme">
      {/* 1. Theme Artwork Background */}
      <div className="dashboard-bg-backdrop" />

      {/* 2. Slowly Rotating Red Moon (Subtle & Non-Overpowering) */}
      <div className="dashboard-bg-moon-layer" aria-hidden="true">
        <TsukuyomiMoon size={540} rotationSpeed={110} showOrbs={true} glow={true} />
      </div>

      {/* 3. Traditional Japanese Red Clouds Looming Over Occasionally */}
      <OrientalClouds />

      {/* 4. Simple, Clean Dashboard Content */}
      <div className="simple-dashboard-content">
        {/* Clean Header Bar */}
        <header className="simple-dashboard-header">
          <div className="brand-group">
            <div className="brand-moon-badge">
              <Moon size={20} color="var(--gold-moon-bright)" />
            </div>
            <div>
              <div className="brand-title-row">
                <span className="brand-title">TSUKUYOMI WATCH</span>
                <span className="hanko-seal">月読</span>
              </div>
              <span className="brand-subtitle">Night Sky & Astrophotography Guide</span>
            </div>
          </div>

          <div className="header-actions">
            {/* Astronomy Facts Button */}
            <button
              type="button"
              onClick={() => setShowFactModal(true)}
              className="simple-fact-pill"
            >
              <Sparkles size={14} color="var(--gold-moon-bright)" />
              <span>Space Facts</span>
            </button>

            {/* Simple Clock */}
            <div className="simple-clock-pill">
              <Clock size={13} color="var(--gold-moon)" />
              <span>{currentTime || '00:00:00'}</span>
            </div>
          </div>
        </header>

        {/* Simple Hero Section */}
        <section className="simple-hero">
          <h1 className="simple-hero-title">Explore the Night Sky</h1>
          <p className="simple-hero-desc">
            Choose a tool below to track satellites, check lunar phases, detect constellations in your photos, or clean up your night shots.
          </p>
        </section>

        {/* Clean 4-Options Grid */}
        <section className="simple-options-grid">
          {options.map((option) => (
            <div
              key={option.id}
              className="simple-option-card"
              style={
                {
                  '--card-accent': option.accentColor,
                  '--card-glow': option.glowColor,
                } as React.CSSProperties
              }
              onClick={() => onSelectOption(option.id)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectOption(option.id);
                }
              }}
              aria-label={`Open ${option.title}`}
            >
              <div className="card-top-row">
                <div className="card-icon-bubble">{option.icon}</div>
                <span className="hanko-seal">{option.japanese}</span>
              </div>

              <div className="card-text-body">
                <h3 className="card-title">{option.title}</h3>
                <span className="card-subtitle">{option.subtitle}</span>
                <p className="card-desc">{option.description}</p>
              </div>

              <div className="card-bottom-row">
                <button
                  type="button"
                  className="card-launch-link"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectOption(option.id);
                  }}
                >
                  <span>{option.launchText}</span>
                  <ArrowRight size={15} />
                </button>
              </div>
            </div>
          ))}
        </section>

        {/* Clean, Simple Footer */}
        <footer className="simple-dashboard-footer">
          <span>Tsukuyomi Watch • Japanese-themed celestial suite</span>
        </footer>
      </div>

      {/* Astronomy Facts Modal with Rotating Red Tsukuyomi Moon */}
      {showFactModal && (
        <LoadingScreen
          subtitle="Fun Astronomy Facts"
          minDurationMs={999999}
          onComplete={() => setShowFactModal(false)}
        />
      )}
    </div>
  );
};
